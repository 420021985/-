//
//  ViewController+_.h
//  tableview3
//
//  Created by apple on 2017/1/11.
//  Copyright © 2017年 xkd. All rights reserved.
//

#import "znxViewController.h"
#import <UIKit/UIKit.h>
#import "znxcell.h"

@interface znxViewController:UIViewController
{
    
}
@property (nonatomic, strong) Person *shuju;
@end
