//
//  Person.m
//  tableview3
//
//  Created by apple on 2016/12/20.
//  Copyright © 2016年 xkd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "znxcell.h"

@implementation Person

@end
