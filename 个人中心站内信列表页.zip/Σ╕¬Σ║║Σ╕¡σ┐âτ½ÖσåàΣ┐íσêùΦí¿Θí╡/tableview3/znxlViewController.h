//
//  ViewController.h
//  tableview3
//
//  Created by apple on 2016/12/20.
//  Copyright © 2016年 xkd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController:UIViewController
{
    
}
@property (nonatomic, strong) IBOutlet UITableViewCell *customCell;
@property (nonatomic, strong) UITableView *tableview;


@end
