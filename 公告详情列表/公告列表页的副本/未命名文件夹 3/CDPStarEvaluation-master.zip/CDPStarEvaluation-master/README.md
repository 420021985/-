# CDPStarEvaluation
Article star evaluation,have been packaged, can click or drag the stars level evaluation and score, the default accurate to two decimal places, according to the custom demand, see the demo

//Need to use delegate can set up their own.
#import "CDPStarEvaluation.h"
_starEvaluation=[[CDPStarEvaluation alloc] initWithFrame:yourFrame onTheView:yourView];
